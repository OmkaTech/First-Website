import React, { Component } from 'react'
import Header from '../Includes/Header'
import Footer from '../Includes/Footer'
import about from '../../assests/about1.jpg'
import about1 from '../../assests/about2.jpg'
import about2 from '../../assests/about3.jpg'

class About extends Component {
    render() {
        return(
            <div>
                <Header {...this.props} />                
                <div class="about-section">
                    <h1>About Us</h1>
                    <p>We are one of the fastest growing IT company having a huge clientele in USA, UK, South Africa, Australia, and many other countries. We do off-shore development and help our clients convert their Ideas into Reality.</p>
                    
                </div>
                <h2 style={{textAlign : 'center'}}>Our Team</h2>
                    <div class="row">
                        <div class="column">
                            <div class="card">
                                <img src={'https://cdn.pixabay.com/photo/2017/10/24/10/30/business-2884023_960_720.jpg'} alt="Jane"  style={{width : '100%'}}  />
                                <div class="container">
                                    <h2>Jane Doe</h2>
                                    <p class="title">CEO & Founder</p>
                                    <p>Some text that describes me lorem ipsum ipsum lorem.</p>
                                    <p>jane@example.com</p>
                                    <p><button class="button">Contact</button></p>
                                </div>
                            </div>
                        </div>
                   
                    <div class="column">
                        <div class="card">
                            <img src={'https://cdn.pixabay.com/photo/2016/03/09/09/22/workplace-1245776_960_720.jpg'} alt="Mike"  style={{width : '100%'}} />
                                <div class="container">
                                    <h2>Mike Ross</h2>
                                    <p class="title">Art Director</p>
                                    <p>Some text that describes me lorem ipsum ipsum lorem.</p>
                                    <p>mike@example.com</p>
                                    <p><button class="button">Contact</button></p>
                                </div>
                        </div>
                    </div>

                    <div class="column">
                        <div class="card">
                            <img src={'https://cdn.pixabay.com/photo/2017/05/04/16/37/meeting-2284501_960_720.jpg'} alt="John"  style={{width : '100%'}} />
                                <div class="container">
                                    <h2>John Doe</h2>
                                    <p class="title">Designer</p>
                                    <p>Some text that describes me lorem ipsum ipsum lorem.</p>
                                    <p>john@example.com</p>
                                    <p><button class="button">Contact</button></p>
                                </div>
                        </div>
                    </div>
                </div>
                <Footer {...this.props} />
            </div>
        )
    }
}

export default About;