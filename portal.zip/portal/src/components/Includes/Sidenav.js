import React,{Component} from 'react';  
import {Spring} from 'react-spring/renderprops'

 class Sidenav extends Component {  
    render() {      
        return (  
          <div>  
            <Spring
            from={{ opacity: 0 , marginTop : -500 }}
            to={{ opacity: 1 , marginTop : 0}}
            config={{  duration : 3000   }}
            >
                { props => (
                    <div style={props}>
                    <header>
                        <div class="owl-carousel owl-theme">
                            <div class="item">
                                <img src={'https://cdn.pixabay.com/photo/2016/03/09/09/22/workplace-1245776_960_720.jpg'} alt="images not found" />
                                <div class="cover">
                                    <div class="container">
                                        <div class="header-content">
                                            <div class="line"></div>
                                                <h1>Web and Mobile<br/> App Development <br /> Company</h1>
                                                <button id="round-button"  className="btn">Contact Us</button>
                                        </div>
                                    </div>
                                </div>
                            </div>                    
                        </div> 
                        </header>  
                    </div>

                )}            
            </Spring>
            
            
       </div>
        )  
    }  
}  

export default Sidenav  