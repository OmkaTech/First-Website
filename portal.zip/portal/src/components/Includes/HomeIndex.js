import React, { Component } from 'react';
import Demo from '../../../src/assests/logo.png'
import Demo2 from '../../../src/assests/image.png'
import img from '../../../src/assests/analysis.png'
import img1 from '../../../src/assests/agreement.png'
import img2 from '../../../src/assests/high-quality.png'
import img3 from '../../../src/assests/methodology.png'
import img4 from '../../../src/assests/Precise condition.png'
import img5 from '../../../src/assests/Delivery.png'
import img6 from '../../../src/assests/Quality.png'
import img7 from '../../../src/assests/marketing.png'
import img8 from '../../../src/assests/ux-design.png'
import img9 from '../../../src/assests/mobile-app.png'
import img10 from '../../../src/assests/digital-marketing.png'
import img11 from '../../../src/assests/joystick.png'
import img12 from '../../../src/assests/code.png'
import img13 from '../../../src/assests/blockchain.png'

class HomeIndex extends Component
{
  render() {
    return(
      <>
  
         
             
          <h1 class="txt mt-5">How We Work</h1>
    <div id="work" class="services-container animated zoomIn">
        <div class="services">
            <div class="services-img"><img class="work-image1" src={img} alt="" /></div>
            <h2>Business Analysis</h2>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eos,
                harum delectus consequuntur quos ea, fugit incidunt ratione esse repudiandae,
                cupiditate officiis accusamus qui architecto eum natus suscipit vitae aliqua</p>
        </div>
        <div class="services">
            <div class="services-img"><img class="work-image1" src={img1} alt="" /></div>
            <h2>Legal Agreement</h2>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eos,
                 harum delectus consequuntur quos ea, fugit incidunt ratione esse repudiandae,
                 cupiditate officiis accusamus qui architecto eum natus suscipit vitae aliqua</p>
        </div>
        <div class="services">
            <div class="services-img"><img class="work-image1" src={img2} alt="" /></div>
            <h2>Guarantees</h2>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eos,
                 harum delectus consequuntur quos ea, fugit incidunt ratione esse repudiandae,
                 cupiditate officiis accusamus qui architecto eum natus suscipit vitae aliqua</p>
        </div>
        <div class="services">
            <div class="services-img"><img class="work-image1" src={img3} alt="" /></div>
            <h2>Agile Development</h2>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eos,
                 harum delectus consequuntur quos ea, fugit incidunt ratione esse repudiandae,
                 cupiditate officiis accusamus qui architecto eum natus suscipit vitae aliqua</p>
        </div>
    </div>
   

    
      </>
    )
  }
}

export default HomeIndex;