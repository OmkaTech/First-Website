import React, {  Component} from 'react'
import Demo2 from '../../../src/assests/logo.png'
import Demo from '../../../src/assests/logo.png'

class Footer extends Component {
    render() {
        return (
        <div >
            





<footer class="page-footer font-large color-dark" style={{backgroundColor: "black"}}>

  <div style={{backgroundColor: "#D3D3D3"}}>
    <div class="container">

  
 

    </div>
  </div>

  <div class="container text-center text-md-left mt-5">

    <div class="row mt-3">

 
      <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">

        <img class="" style={{ fontSize : "16px"}} src={Demo} alt="Omka Tech" />
       
        <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto " ></hr>
        <p className="text-white"  style={{ fontSize :  "16px"}}>We are one of the fastest growing IT company having a huge clientele in USA, UK, South Africa, Australia, and many other countries. We do off-shore development and help our clients convert their Ideas into Reality..</p>

      </div>
    
      <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">

    
        <h6 class="text-uppercase font-weight-bold text-white " style={{fontSize: "16px"}}>Our Project</h6>
        <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto"  style={{ width :  "60px"}}></hr>
        <p style={{fontSize: "16px"}}>
          <a type="button"  className="text-primary">Website 1</a>
        </p>
        <p style={{fontSize: "16px"}}>
          <a type="button"  className="text-white">Website 2</a>
        </p>
        <p style={{fontSize: "16px"}}>
          <a type="button"  className="text-white">Website 3</a>
        </p>
        <p style={{fontSize: "16px"}}>
          <a type="button"  className="text-white">Website 4</a>
        </p>

      </div>
     
      <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">

        <h6 class="text-uppercase  text-white" style={{fontSize: "16px"}}>Navigate</h6>
        <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto"  style={{ width :  "60px"}}></hr>
        <p style={{fontSize: "16px"}} >
          <a type="button"  className="text-white" >About</a>
        </p>
        <p style={{fontSize: "16px"}}>
          <a type="button" className="text-white" >Services</a>
        </p>
        <p style={{fontSize: "16px"}}>
          <a type="button"  className="text-white">Portfolio</a>
        </p>
        <p style={{fontSize: "16px"}}>
          <a type="button" className="text-white" >Technology</a>
        </p>

      </div>
     


      <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">

    
        <h6 class="text-uppercase font-weight-bold text-white" style={{fontSize: "16px"}}>Find Us Here</h6>
        <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto text-white"  style={{ width :  "60px"}}></hr>
        <p className="text-white" style={{fontSize: "16px"}}>
          <i class="fas fa-home mr-3 text-white" ></i> Plot No.183, Sector-28,Faridabad,Haryana & A Block Sector-46,Noida,Uttar Pradesh</p>
        <p className="text-white" style={{fontSize: "16px"}}>
          <i class="fas fa-envelope text-white mr-3"></i> info@omkatech.com</p>
        <p className="text-white" style={{fontSize: "16px"}}>
          <i class="fas fa-phone text-white mr-3"></i> USA- +1 7864754171
</p>
        <p className="text-white" style={{fontSize: "16px"}}>
          <i class="fas fa-print text-white mr-3"></i> INDIA- +91 9717511913</p>

      </div>


    </div>
   

  </div>
  
  <div class="footer-copyright text-center py-3 text-white" style={{fontSize: "16px"}}>@ 2020 OmkaTech. All Rights Reserved:
    <a style={{fontSize: "16px"}} href="http://localhost:3000/"> Omkatech.com</a>
  </div>
 

</footer>

         </div>
        )
    }
}

export default Footer;