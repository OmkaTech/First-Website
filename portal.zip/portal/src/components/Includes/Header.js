import React, { Component  } from 'react'
import logo from '../../../src/assests/om1.png'

class Header extends Component {

  mouseEnter = (e) => {
    console.log('stop');
  }
  render() {
    return(
      <div>
      <div className="banner">
        <p className="animated slideInRight" onMouseEnter={"stop"} id="banner">COVOID-19-All our teamare safely working remotely to meet your tech requirement prompty</p>
      </div>

      <div class="header">
      <img class="logo" onClick={() => {this.props.history.push('/') ; }} src={logo} alt="Omka Tech" />
      
      
      <div class="header-right">
        <a  type="button" onClick={ () => {this.props.history.push('Service') ; }}>Services</a>
        <a type="button" onClick={ () => {this.props.history.push('/')}}>Technology</a>
        <a  type="button" >Ready to Use</a>
        <a  type="button" onClick={ () => {this.props.history.push('Client') ; }}>Portfolio</a>
        <a type="button" onClick={ () => {this.props.history.push('About') ; }}  >About Us</a>
        <a  type="button">Contact Us</a>
        {/* <a  type="button" onClick={ () => {this.props.history.push('Contact')}}  className="btn">Get in touch</a> */}
      </div>
  </div>
  </div>
    )
  }
}

export default Header;