import React from 'react';
import Routes from './Routes'
import Demo from './assests/logo.png'

function App() {
  return (
    
            <Routes />
       
    
  );
}

export default App;


