import React, { Component } from 'react'
import Home from './components/Includes/Home'
import { BrowserRouter as Router, Route, Switch  } from 'react-router-dom'
import Header from './components/Includes/Header'
import Footer from './components/Includes/Footer'
import HomeIndex from './components/Includes/HomeIndex'
import Sidenav from './components/Includes/Sidenav'
import About from './components/FrontEnd/About'
import Service from './components/FrontEnd/Service'
import Client from './components/FrontEnd/Client'
import Contact from './components/FrontEnd/Contact'
import Admin from './components/Admin/Home'
import Login from './components/Admin/Login'

class Routes extends Component {
    render() {
        return(
            <Router>
                <Switch>
                    <Route exact path="/" render={(props) => <Home {...props} />} /> 
                    <Route exact path="/Header" render={(props) => <Header {...props} />} />
                    <Route exact path="/Footer" render={(props) => <Footer {...props} />} />
                    <Route exact path="/HomeIndex" render={(props) => <HomeIndex {...props} />} /> 
                    <Route exact path="/Sidenav" render={(props) => <Sidenav {...props} />} /> 
                    <Route exact path="/About" render={(props) => <About {...props} />} /> 
                    <Route exact path="/Service" render={(props) => <Service {...props} />} />  
                    <Route exact path="/Client" render={(props) => <Client {...props} />} />
                    <Route exact path="/Contact" render={(props) => <Contact {...props} />} />    
                    <Route exact path="/Admin" render={(props) => <Admin {...props} />}/>    
                    <Route exact path="/Login" render={(props) => <Login {...props} />}/>                                                   
                </Switch>
            </Router>
        )
    }
}

export default Routes;