import React, { Component } from 'react'
import Header from '../Includes/Header'
import Footer from '../Includes/Footer'

class Contact extends Component {
    render() {
        return(
            <div>
                <Header {...this.props} />
                    <div className="container" >
                        <div className="row">
                            <div className="col-md-8 col-sm-6 col-lg-4 mx-auto border mt-5 p-5 mb-5">
                            <h1 className="text-center">Contact Us</h1>
                                <form >
                                    
                                    <label for="name">Name : </label>
                                    <input type="text" className="form-control" name="name"/>

                                    <label for="phone">Phone : </label>
                                    <input type="text" className="form-control" name="phone"/>

                                    <label for="email">Email : </label>
                                    <input type="email" className="form-control" name="email"/>

                                     <label for="message">Message : </label>
                                    <textarea class="form-control" rows="2" name="message" id="message"></textarea><br/>

                                    <button type="button" target="_blank" className="btn btn-success " >Send</button>
                                </form>
                            </div>
                        </div>
                    </div>
                <Footer {...this.props} />
            </div>
        )
    }
}

export default Contact;